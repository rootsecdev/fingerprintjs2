---
name: Changing fingerprints
about: Collected fingerprints change unexpectedly

---

<!--
BUG REPORTS NOT USING THE TEMPLATE ARE SUBJECT TO BEING CLOSED WITHOUT COMMMENT.
-->

### Scenario

- What causes the fingerprint to change?
- What device and browser are you using?
- What version of fingerprintjs are you using? (Bug reports not applicable to fingerprintjs master are subject to be closed without comment.)

### Fingerprint data

Provide the FULL DATA of both/all fingerprints using this jsfiddle https://jsfiddle.net/L2gLq4rg/85/.
Alternatively, provide a jsfiddle that reproduces the bug.
